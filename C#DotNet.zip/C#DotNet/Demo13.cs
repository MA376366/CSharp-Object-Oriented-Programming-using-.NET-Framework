﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo13
{
    class Demo13
    {
        static void Main(string[] args)
        {
            StringBuilder builder = new StringBuilder("Wipro ");
            builder.AppendLine("Technologies ").Append("Bangalore");
            Console.Write(builder);
            Console.ReadLine();
        }
    }
}
