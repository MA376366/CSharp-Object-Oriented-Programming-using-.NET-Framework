﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo14
{
    class Demo14
    {
        static void Main(string[] args)
        {
            List<string> colors = new List<string>();
            colors.Add("Red");
            colors.Add("Blue");
            colors.Add("Green");
      Code:      Console.WriteLine("Enter your choice (1-4) :");
            Console.WriteLine("1. ViewAll");
            Console.WriteLine("2. Insert");
            Console.WriteLine("3. Update");
            Console.WriteLine("4. Delete");
            int ch = int.Parse(Console.ReadLine());
            switch (ch)
            {
                case 1:
                    foreach (string color in colors)
                    {
                        Console.WriteLine(color);
                    }
                    Console.WriteLine("Want to continue (Y/N)");
                    string result1 = Console.ReadLine();
                    if (result1 == "Y" )
                    {
                        goto Code;
                    }
                    break;
                case 2:
                    Console.WriteLine("Enter color to add");
                    string newcolor = Console.ReadLine();
                    colors.Add(newcolor);
                    Console.WriteLine("Added !!!");
                    Console.WriteLine("Want to continue (Y/N)");
                    string result2 = Console.ReadLine();
                    if (result2 == "Y")
                    {
                        goto Code;
                    }
                   
                    break;
                case 3:
                    Console.WriteLine("Enter Value to Find");
                    string oldcolor = Console.ReadLine();
                    for (int i = 0; i < colors.Count; i++)
                    {
                        if (colors[i].Contains(oldcolor))
                        {
                            Console.WriteLine("Found");
                            Console.WriteLine("");
                            Console.WriteLine("Enter Value to update");
                            string updatecolor = Console.ReadLine();
                            colors.RemoveAt(i);
                            colors.Insert(i, updatecolor);
                            Console.WriteLine("Want to continue (Y/N)");
                            string result3 = Console.ReadLine();
                            if (result3 == "Y")
                            {
                                goto Code;
                            }
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Not Found");
                            Console.WriteLine("Want to continue (Y/N)");
                            string result4 = Console.ReadLine();
                            if (result4 == "Y")
                            {
                                goto Code;
                            }
                            break;
                        }
                    }
                    break;
                case 4:
                    Console.WriteLine("Enter the color: ");
                    string delete = Console.ReadLine();
                    for (int i = 0; i < colors.Count; i++)
                    {
                        if (colors[i].Contains(delete))
                        {
                            colors.RemoveAt(i);
                            Console.WriteLine("Deleted");

                            Console.WriteLine("Want to continue (Y/N)");
                            string result6 = Console.ReadLine();
                            if (result6 == "Y")
                            {
                                goto Code;
                            }
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Not Found");
                            Console.WriteLine("Want to continue (Y/N)");
                            string result7 = Console.ReadLine();
                            if (result7 == "Y")
                            {
                                goto Code;
                            }
                            break;
                        }
                    }
                    break;
                default:
                    Console.WriteLine("Invalid choice try later!!!");
                    Console.WriteLine("Want to continue (Y/N)");
                    string result = Console.ReadLine();
                    if (result == "Y")
                    {
                        goto Code;
                    }
                    break;

            }
            Console.ReadLine();
        }
    }
}
