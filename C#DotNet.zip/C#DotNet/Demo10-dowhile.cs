﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo10_dowhile
{
    class Program
    {
        int x=1;
        public void Demo()
        {
            do
            {
                Console.WriteLine(x);
                x++;
            }
            while (x <= 20);

        }
        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.Demo();
            Console.ReadLine();
        }
    }
}
