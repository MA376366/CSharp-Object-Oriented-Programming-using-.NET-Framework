﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo10_while
{
    class Demo
    {
        int x=1;
        public void whiledemo()
        {
            while (x <= 20)
            {
                Console.WriteLine(x);
                x++;
            }
        }
        static void Main(string[] args)
        {
            Demo obj = new Demo();
            obj.whiledemo();
            Console.ReadLine();
        }
    }
}
