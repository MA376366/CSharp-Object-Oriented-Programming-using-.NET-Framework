﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TopGear30_11_2017
{
    class Demo1
    {
        static void Main(string[] args)
        {
            string input = "DemoProgram";
            string sub = input.Substring(4);
            string left = input.Substring(0, 5);
            string right = input.Substring(6, 5);
            string middle = input.Substring(4, 6);
            Console.WriteLine("Substring: {0}", sub);
            Console.WriteLine("First 5 Left Characters: {0}", left);
            Console.WriteLine("Last 5 Right Characters: {0}", right);
            Console.WriteLine("Middle Characters: {0}", middle);
            Console.ReadLine();
        }
    }
}
