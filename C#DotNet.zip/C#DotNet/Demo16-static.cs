﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo16
{
    static class Example
    {
        public static string StaticMember = "This is Static Member";
        public static void StaticMethod()
        {
            Console.WriteLine("This is Static Method");
        }
    }
    class Demo16
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Example.StaticMember);
            Example.StaticMethod();
            Console.ReadLine();
        }
    }
}
