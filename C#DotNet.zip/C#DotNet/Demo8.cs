﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo8
{
    public class Employee
    {
        public Employee()
        {
            this.ID = 0;
            this.Name = "N/A";
        }
        public Employee(int id, string name)
        {
            this.ID = id;
            this.Name = name;
        }
        public int ID { get; set; }
        public string Name { get; set; }
        public void getData()
        {
            Console.WriteLine("Enter the Employee ID");
            ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Employee Name");
            Name = Console.ReadLine();
        }

        public void showData()
        {
            Console.WriteLine("\n Employee ID = " + ID);
            Console.WriteLine(" Employee Name = " + Name);
        }
    }
    class Manager : Employee
    {
        public Manager()
        {
            Role = "N/A";
        }
        public string Role { get; set; }
        public void getRole()
        {
            Console.WriteLine("Enter the Employee Role");
            Role = Console.ReadLine();
        }
        public void showRole()
        {
            Console.WriteLine(" Employee Role is " + Role);
        }
    }
    class Demo8
    {
        static void Main(string[] args)
        {
            Manager obj = new Manager();
            obj.getData();
            obj.getRole();
            obj.showData();
            obj.showRole();

            Console.ReadLine();
        }
    }
}
