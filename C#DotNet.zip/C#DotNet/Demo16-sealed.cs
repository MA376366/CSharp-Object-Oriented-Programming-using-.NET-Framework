﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo16_sealed
{
    sealed public class Employee
    {
        public int Salary(int x, int y)
        {
            return x + y;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee obj = new Employee();
            int total = obj.Salary(8000, 5000);
            Console.WriteLine("Total = " + total.ToString());
            Console.ReadLine();
        }
    }
}
