﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo5
{
    class Demo5
    {
        abstract class Shape
        {
            abstract public int Area();
        }
        class square : Shape
        {
            int side = 0;
            public square(int n)
            {
                side = n;
            }
            public override int Area()
            {
                return side * side;
            }
        }
        static void Main(string[] args)
        {
            square Square = new square(20);
            Console.WriteLine("Area of the square = {0}", Square.Area());
            Console.ReadLine();
        }
    }
}
