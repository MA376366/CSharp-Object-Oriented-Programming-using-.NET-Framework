﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo7
{
   class Demo7
     {
        public class Shape
        {
            public void Area(float r)
            {
                float a = (float)3.14 * r;
               
                Console.WriteLine("Area of a circle: {0}", a);
            }

            public void Area(float l, float b)
            {
                float x = (float)l * b;
               
                Console.WriteLine("Area of a rectangle: {0}", x);

            }

            public void Area(float a, float b, float c)
            {
                float s = (float)(a * b * c) / 2;
         
                Console.WriteLine("Area of a circle: {0}", s);
            }
            static void Main(string[] args)
            {
                Shape obj = new Shape();
                obj.Area(2.0f);
                obj.Area(20.0f, 30.0f);
                obj.Area(2.0f, 3.0f, 4.0f);
                Console.ReadLine();
            }
        }
    }
}
