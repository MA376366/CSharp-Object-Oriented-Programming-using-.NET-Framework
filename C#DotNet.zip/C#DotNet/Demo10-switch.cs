﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo10_switch_statement
{
    class Program
    {
        int ch;
        public void getdata()
        {
            Console.WriteLine("Enter your choice (1-3) :");
            ch = int.Parse(Console.ReadLine());
            switch (ch)
            {
                case 1:
                    Console.WriteLine("you choose Red");
                    break;
                case 2:
                    Console.WriteLine("you choose Green");
                    break;
                case 3:
                    Console.WriteLine("you choose Pink");
                    break;
                default:
                    Console.WriteLine("Invalid choice try later!!!");
                    break;

            }
        }
        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.getdata();
            Console.ReadLine();
        }
    }
}
