﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo10_for
{
    class Program
    {
        public void getdata()
        {

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine(i);
            }
        }
        static void Main(string[] args)
        {

            Program obj = new Program();
            obj.getdata();
            Console.ReadLine();
        }
    }
}
