﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo10
{
    class Demo10
    {
        static void Main(string[] args)
        {
            int a, b;
            Console.WriteLine("enter 2 no ");
            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());

            //IF Statement
            if (a > b)
            {
                Console.WriteLine("a is greather");
            }
            else if(a < b)
             {
                Console.WriteLine("b is greather");
            }  
            else   
             {
                 Console.WriteLine("both are Equals");
             }
            Console.ReadLine();
        }
    }
}
