﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class Demo2
    {
        static void Main(string[] args)
        {
            const string input = "Tech World";
            Console.WriteLine("BEFORE REPLACE");
            Console.WriteLine(input);
            string output = input.Replace("Tech ", "Technology ");
            Console.WriteLine("AFTER REPLACE");
            Console.WriteLine(output);
            Console.ReadLine();
        }
    }
}
