﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo11
{
    class employee
    {
        private string name;
        private int age;
       
        public employee(string name, int age) 
        {
            this.name = name;
            this.age = age;
        }
        public string Details     
        {
            get
            {
                return " The age of " + name + " is " + age.ToString();
            }
        }
    }
    class Demo11
    {
        static void Main(string[] args)
        {
            employee emp1 = new employee("Adams", 23);
            employee emp2 = new employee("James", 21);
            Console.WriteLine(emp1.Details);
            Console.WriteLine(emp2.Details);
            Console.ReadLine();
        }
    }
}
