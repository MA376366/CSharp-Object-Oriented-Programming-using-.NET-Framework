﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo6
{
    class Test
    {
        //Public method
        public void MethodPublic()
        {
        }
        //Private method
        private void MethodPrivate()
        {
        }
        //Internal method
        internal void MethodInternal()
        {
        }
    }
    class Test1
    {
        //Protected variable
        protected int obj2;
    }

    class Test2 : Test1
    {
        Test2()
        {
            this.obj2 = 10; // can access from this class
        }
    }

    class Test3
    {
        Test3()
        {
            this.obj2 = 10; // can't access from this class
        }
    }
    class Demo6
    {
        static void Main(string[] args)
        {
                Test obj1 = new Test();

                obj1.MethodPublic();  // valid code to access.

                obj1.MethodPrivate();  //Invalid to access, Error will come.

                obj1.MethodInternal(); // valid code to access.  
        }
    }
}
